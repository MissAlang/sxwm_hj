<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/3/22
 * Time: 15:05
 * @copyright: (c)2019 天幕网络
 * @link: http://www.67930603.top
 */

namespace app\events;


use app\models\Share;
use yii\base\Event;

/**
 * @property Share $share
 */
class ShareEvent extends Event
{
    public $share;
}
