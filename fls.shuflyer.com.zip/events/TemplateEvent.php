<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/12/25
 * Time: 14:27
 * @copyright: (c)2019 天幕网络
 * @link: http://www.67930603.top
 */

namespace app\events;


use yii\base\Event;

class TemplateEvent extends Event
{
    public $templateTpl;
}
