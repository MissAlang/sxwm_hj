<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'zjhj_mall_v4',
    'username' => 'zjhj_mall_v4',
    'password' => '123456',
    'tablePrefix' => 'hjmall_',
];
