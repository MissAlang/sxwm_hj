<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'fls_shuflyer_com',
    'username' => 'fls_shuflyer_com',
    'password' => 'f8hbAXHbJ3PFwtj2',
    'tablePrefix' => 'zjhj_bd_',
];
