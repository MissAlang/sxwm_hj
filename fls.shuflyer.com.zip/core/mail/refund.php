<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/5/13
 * Time: 20:21
 * @copyright: (c)2019 天幕网络
 * @link: http://www.67930603.top
 */
?>
<p>尊敬的:<b><?= $mall->name; ?></b></p>
<h1>您有一个新的退款订单</h1>
<p>请及时进入商城处理</p>
