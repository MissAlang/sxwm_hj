<?php
/**
 * @copyright (c)天幕网络
 * @author Lu Wei
 * @link http://www.67930603.top/
 * Created by IntelliJ IDEA
 * Date Time: 2018/12/11 12:02
 */


namespace app\core\payment;


use app\models\Model;

class PaymentOrderModel extends Model
{
    public $orderNo;

}