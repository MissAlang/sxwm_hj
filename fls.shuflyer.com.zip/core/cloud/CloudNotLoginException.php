<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2019/3/6
 * Time: 10:08:00
 */

namespace app\core\cloud;


class CloudNotLoginException extends \Exception
{

}
