<?php
/**
 * @copyright (c)天幕网络
 * @author Lu Wei
 * @link http://www.67930603.top/
 * Created by IntelliJ IDEA
 * Date Time: 2019/1/4 18:20:00
 */

namespace app\core\cloud;

class CloudAuth {
	public $classVersion = '4.2.10';
	public function getAuthInfo() {
		return [
			'host' => [
				'account_num' => 9999,
			],
		];
	}
	
}

?>